class Patient1 < ApplicationRecord
    belongs_to :doctor
    
end