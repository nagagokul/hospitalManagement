class HomeController < ApplicationController
    
end
