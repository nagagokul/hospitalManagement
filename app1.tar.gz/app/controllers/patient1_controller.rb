class Patient1Controller < ApplicationController
    def list
    @patients=Patient1.all
    @doctor=Doctor.all
    end

        
    def show
    @patient=Patient1.find(params[:id])
    end
    
    def new
    @patient=Patient1.new
    @doctor=Doctor.all
    end

    def patient_params
        params.require(:patient).permit(:patientid, :name, :age, :sex, :email, :doctor_id, :cause, :status)
    end
    
    def create
        @patient = Patient1.new(patient_params)
	
        if @patient.save
           redirect_to :action => 'list'
        else
            @doctor=Doctor.all
            render :action => 'new'
        end
    end
    
    def edit
        @patients = Patient1.find(params[:id])
        @doctors = Doctor.all
    end
    
    def patient_param
        params.fetch(:patient1, {}).permit(:patientid, :name, :age, :sex, :email, :doctor_id, :cause, :status)
    end

    def update
        @patient = Patient1.find(params[:id])
        if @patient.update_attributes(patient_param)
            redirect_to :action => 'show', :id => @patient
         else
            @doctors = Doctor.all
            render :action => 'edit'
         end
    end
    
    def delete
        Patient1.find(params[:id]).destroy
        redirect_to :action => 'list'
    end
    
    
    def show_doctor
        @doctor=Doctor.all
    end
    def show_doctor1
        @doctor=Doctor.find(params[:id])
        @name=@doctor.name
        @patients=@doctor.patient1s
    end
end
